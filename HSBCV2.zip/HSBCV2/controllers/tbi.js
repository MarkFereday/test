var express = require('express'),
  router = express.Router()

function validateUrl(req, res) {
  if (Object.keys(req.query).length === 0) {
    res.redirect('/tbi/alerts')
    return false;
  }
  return true;
}

router.get('/podalerts', function (req, res) {
  // if (!validateUrl(req, res)) {return false;} 
  res.render('podiumalert.ejs', {
    currentpage: 'Podium Alerts',
    pagegroup: 'TBI',
    qlik_positioning_file: 'qlik_podiumalert',
    menu_id: 'podiumalert'
  });
})

router.get('/revenue', function (req, res) {
  if (!validateUrl(req, res)) {return false;} 
  //check the user is the owner of the item, otherwise redirect to public page.
  res.render('revenue.ejs', {
    currentpage: 'Revenue',
    pagegroup: 'TBI',
    qlik_positioning_file: 'qlik_revenue',
    menu_id: 'revenueLink'
  });
})

router.get('/pipeline', function (req, res) {
  if (!validateUrl(req, res)) {return false;} 
  res.render('pipeline.ejs', {
    currentpage: 'Pipeline',
    pagegroup: 'TBI',
    qlik_positioning_file: 'qlik_pipeline',
    menu_id: 'pipelineLink'
  });
})

router.get('/clientplayingfield2', function (req, res) {
  res.render('clientplayingfield2.ejs', {
    currentpage: 'Client Playing Field',
    pagegroup: 'TBI',
    qlik_positioning_file: 'qlik_clientplayingfield2',
    menu_id: 'clientPlayingFieldLink'
  });
})

router.get('/clientplayingfield', function (req, res) {
  if (!validateUrl(req, res)) {return false;} 
  res.render('clientplayingfield.ejs', {
    currentpage: 'Client Playing Field',
    pagegroup: 'TBI',
    qlik_positioning_file: 'qlik_clientplayingfield',
    menu_id: 'clientPlayingFieldLink'
  });
})

router.get('/plan', function (req, res) {
  if (!validateUrl(req, res)) {return false;}   
  res.render('clientplanning.ejs', {
    currentpage: 'Client Planning',
    pagegroup: 'TBI',
    qlik_positioning_file: 
    'qlik_clientplanning',
    menu_id: 'clientPlanning'
  });
})

router.get('/crossselling', function (req, res) {
  if (!validateUrl(req, res)) {return false;}   
  res.render('xselling.ejs', {
    currentpage: 'Cross Selling',
    pagegroup: 'TBI',
    qlik_positioning_file:
    'qlik_xselling',
    menu_id: 'crossSelling'
  });
})

router.get('/alerts', function (req, res) {
  res.render('alerts.ejs', {
    currentpage: 'Alerts',
    pagegroup: 'TBI',
    qlik_positioning_file:
    'qlik_alerts',
    menu_id: 'alertsLink'
  });
})

router.get('/alerts_detail', function (req, res) {
  if (!validateUrl(req, res)) {return false;} 
  res.render('alerts_detail.ejs', {
    currentpage: 'Alerts Detail',
    pagegroup: 'TBI',
    qlik_positioning_file:
    'qlik_alerts_detail',
    menu_id: 'alertsLink'
  });
})

module.exports = router
