var express = require('express'),
  router = express.Router()

function validateUrl(req, res) {
  if (Object.keys(req.query).length === 0) {
    res.redirect('/tbi/alerts')
    return false;
  }
  return true;
}

router.get('/analysis', function (req, res) {
  // if (!validateUrl(req, res)) {return false;} 
  res.redirect('/glcm/clientplayingfield?alertObj={"view":"101","var":"vKPI_CPF_Text_12","dim":[],"name":[]}')
})

router.get('/clientplayingfield', function (req, res) {
  if (!validateUrl(req, res)) {return false;} 
  res.render('clientplayingfield.ejs', {
    currentpage: 'Client Playing Field',
    pagegroup: 'GLCM',
    qlik_positioning_file: 'qlik_clientplayingfield',
    menu_id: 'clientPlayingFieldLink'
  });
})

module.exports = router
