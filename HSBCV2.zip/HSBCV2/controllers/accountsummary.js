var express = require('express')
  , router = express.Router()
// router/routes.js


        console.log('router mounted');

        router.get('/', function (req, res) {

          console.log('account playing field');

          res.send('hello');

        })



        router.get('/clientplayingfield', function (req, res) {

          //check the user is the owner of the item, otherwise redirect to public page.
          res.render('clientplayingfield.ejs', {currentpage: 'Client Playing Field', pagegroup: 'Account Summary', qlik_positioning_file: 'qlik_clientplayingfield'});

        })

        router.get('/accountbehaviour', function (req, res) {
          //check the user is the owner of the item, otherwise redirect to public page.
          res.render('accountbehaviour.ejs', {currentpage: 'Account Behaviour', pagegroup: 'Account Summary', qlik_positioning_file: 'qlik_accountbehaviour'});

        })

        router.get('/accountstatusanalysis', function (req, res) {
          //check the user is the owner of the item, otherwise redirect to public page.
          res.render('accountstatusanalysis.ejs', {currentpage: 'Account Status Analysis', pagegroup: 'Account Summary', qlik_positioning_file: 'qlik_accountstatusanalysis'});

        })

module.exports = router
