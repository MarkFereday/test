var express = require('express')
  , router = express.Router()
// router/routes.js



    // process the signup form
    // router.post('/signup', do all our passport stuff here);

    // =====================================
    // PROFILE SECTION =====================
    // =====================================
    // we will want this protected so you have to be logged in to visit
    // we will use route middleware to verify this (the isLoggedIn function)

/*
    router.get('/', function (req, res) {
      res.send('Hello World1!')
    })
*/
router.use('/gbm', require('./gbm'));

router.get('/connectqlik.js', function (req, res) {
  //check the user is the owner of the item, otherwise redirect to public page.
  res.render('connectqlik.ejs', {});
})

router.get('/', function (req, res) {
  //check the user is the owner of the item, otherwise redirect to public page.
  //res.render('landing.ejs', {});
  res.redirect('/gbm/audit');
})

module.exports = router
