var express = require('express'),
  router = express.Router()

function validateUrl(req, res) {
  if (Object.keys(req.query).length === 0) {
    res.redirect('/tbi/alerts')
    return false;
  }
  return true;
}

router.get('/audit', function (req, res) {
  // if (!validateUrl(req, res)) {return false;} 
  res.render('audit.ejs', {
    currentpage: 'Issues',
    pagegroup: 'gbm',
    qlik_positioning_file: 'qlik_audit',
    menu_id: 'issuesLink'
  });
})


module.exports = router
