var gulp = require('gulp'),
    gutil = require('gulp-util'),
    clean = require('gulp-clean'),
    less = require('gulp-less');

gulp.task('watch', function() {
    gulp.watch('less/*.less', ['less-min']);
    gulp.watch('less/**/*.less', ['less-min']);
});

gulp.task('less-min', function () {
  return gulp.src('less/some-style.less')
             .pipe(less().on('error', function (err) {
               console.log(err);
             }))
             .pipe(gulp.dest('public/vendor/hsbccustom/css'));
});

gulp.task('less-min-qs', function () {
  return gulp.src('less/qs.less')
             .pipe(less().on('error', function (err) {
               console.log(err);
             }))
             .pipe(gulp.dest('public/vendor/qlikStyle/css'));
});

gulp.task('copyFonts', function() {
    gulp.src('less/new-di-plus/style/NextforHSBC-stack/**/*.*')
        .pipe(gulp.dest('public/vendor/hsbccustom/css/NextforHSBC-stack'));
});

gulp.task('build', ['less-min','less-min-qs', 'copyFonts']);

gulp.task('clean', function () {
     gulp.src('public/vendor/hsbccustom/*.*', {read: false})
         .pipe(clean());
    gulp.src('public/vendor/hsbccustom/css', {read: false})
        .pipe(clean());
});

gulp.task('default', ['watch']);
